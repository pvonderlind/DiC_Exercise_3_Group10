#!/bin/bash
docker run -v $(pwd):/app -p 5010:5000 dic-assignment
