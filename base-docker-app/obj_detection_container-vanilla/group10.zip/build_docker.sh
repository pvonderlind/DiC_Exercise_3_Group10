#!/bin/bash
docker build -t dic-assignment .
