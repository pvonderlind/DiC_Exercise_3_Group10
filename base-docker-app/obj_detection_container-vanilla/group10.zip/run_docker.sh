#!/bin/bash
docker run -v $(pwd):/app -p 5000:5000 dic-assignment
